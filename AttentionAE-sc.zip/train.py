# -*- coding: utf-8 -*-
"""
Created on Wed Sep 28 14:57:57 2022

@author: LSH
"""

import torch
import torch.optim.lr_scheduler as lr_scheduler
import utils
from loss import ZINBLoss
import numpy as np
from sklearn.metrics import silhouette_score, adjusted_rand_score, normalized_mutual_info_score

#random.seed(1)

def train(init_model, Zscore_data, rawData, celltype, adj, r_adj, size_factor, device, args):
    init_model.to(device)
    data = torch.Tensor(Zscore_data).to(device)
    sf = torch.autograd.Variable((torch.from_numpy(size_factor[:,None]).type(torch.FloatTensor)).to(device),
                           requires_grad=True)
    optimizer = torch.optim.Adam(init_model.parameters(), lr=args.lr)
    adj = torch.Tensor(adj).to(device)
    scheduler = lr_scheduler.StepLR(optimizer, step_size=40, gamma=0.5, last_epoch=-1)
    best_model = init_model
    loss_update = 100000
    for epoch in range(args.training_epoch):
        z, A_pred, pi, mean, disp = init_model(data, adj)
        l = ZINBLoss(theta_shape=(args.n_input,))
        zinb_loss = l(mean * sf, pi, target=torch.tensor(rawData).to(device), theta=disp)
        re_graphloss = torch.nn.functional.mse_loss(A_pred.view(-1), torch.Tensor(r_adj).to(device).view(-1))
        loss = zinb_loss + 0.1*re_graphloss
        
        if (epoch+1) % 10 == 0:
            print("epoch %d, loss %.4f, zinb_loss %.4f, re_graphloss %.4f" 
                            % (epoch+1, loss, zinb_loss, re_graphloss))
            
        if loss_update > loss:
            loss_update = loss
            best_model = init_model
            epoch_update = epoch
            
        if ((epoch - epoch_update) > 50):
            print("Early stopping at epoch {}".format(epoch_update))
            print("Finish Training!")
            return best_model 
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(init_model.parameters(), max_norm=3, norm_type=2)
        optimizer.step()
        scheduler.step()
    print("Finish Training!")
    return best_model
    
alpha = 1
def loss_func(z, cluster_layer):
    q = 1.0 / (1.0 + torch.sum((z.unsqueeze(1) - cluster_layer) ** 2, dim=2) / alpha)
    q = q ** (alpha + 1.0) / 2.0
    q = (q.t() / torch.sum(q, dim=1)).t()

    weight = q ** 2 / torch.sum(q, dim=0)
    p = (weight.t() / torch.sum(weight, dim=1)).t()

    log_q = torch.log(q)
    loss = torch.nn.functional.kl_div(log_q, p, reduction='batchmean')
    return loss, p
   
def clustering(pretrain_model, Zscore_data, rawData, celltype, adj, r_adj, size_factor, device, args):
    data = torch.Tensor(Zscore_data).to(device)
    adj = torch.Tensor(adj).to(device)
    model = pretrain_model.to(device)
    sf = torch.autograd.Variable((torch.from_numpy(size_factor[:,None]).type(torch.FloatTensor)).to(device),
                          requires_grad=True)
    #cluster center
    with torch.no_grad():
        z, _, _, _, _  = model(data,adj)
        
    cluster_centers, init_label = utils.use_Leiden(z.detach().cpu().numpy(), n_neighbors=0)
    cluster_layer = torch.autograd.Variable((torch.from_numpy(cluster_centers).type(torch.FloatTensor)).to(device),
                           requires_grad=True)
    asw = np.round(silhouette_score(z.detach().cpu().numpy(), init_label), 3)
    nmi = np.round(normalized_mutual_info_score(celltype, init_label), 3)
    ari = np.round(adjusted_rand_score(celltype, init_label), 3)
    print('init: ASW= %.3f, ARI= %.3f, NMI= %.3f' % (asw, ari, nmi)) 
    
    optimizer = torch.optim.Adam(list(model.enc_1.parameters()) + list(model.enc_2.parameters()) + 
                                  list(model.attn1.parameters()) + list(model.attn2.parameters()) + 
                                  list(model.gnn_1.parameters()) + list(model.gnn_2.parameters()) +
                                 list(model.z_layer.parameters()) + [cluster_layer], lr=0.001)   
    
    for epoch in range(args.clustering_epoch):
        z, A_pred, pi, mean, disp = model(data, adj)
        kl_loss, ae_p = loss_func(z, cluster_layer)
        l = ZINBLoss(theta_shape=(args.n_input,))
        zinb_loss = l(mean * sf, pi, target=torch.tensor(rawData).to(device), theta=disp)
        re_graphloss = torch.nn.functional.mse_loss(A_pred.view(-1), torch.Tensor(r_adj).to(device).view(-1))
        loss = kl_loss + 0.1 * zinb_loss + 0.01*re_graphloss
        loss.requires_grad_(True)
        label = utils.dist_2_label(ae_p)
        
        asw = silhouette_score(z.detach().cpu().numpy(), label)
        ari = adjusted_rand_score(celltype, label)
        nmi = normalized_mutual_info_score(celltype, label)
       

        if (epoch+1) % 10 == 0:
            print("epoch %d, loss %.4f, kl_loss %.4f, ASW %.3f, ARI %.3f, NMI %.3f"% (epoch+1, loss, kl_loss, asw, ari, nmi))
        num = data.shape[0]
        tol=1e-3
        if epoch ==0:
            last_label = label
        else:
            delta_label = np.sum(label != last_label).astype(np.float32) / num
            last_label = label
            if epoch>20 and delta_label < tol:
                print('delta_label ', delta_label, '< tol ', tol)
                print("Reach tolerance threshold. Stopping training.")
                break  
        optimizer.zero_grad()
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=3, norm_type=2)
        optimizer.step()
    print("Finish Clustering!")

    return asw, ari, nmi, last_label, cluster_layer, model

if __name__ == "__main__":
    from warnings import simplefilter 
    import random
    from sklearn import preprocessing
    from model import AttentionAE
    import pandas as pd
    import argparse
    parser = argparse.ArgumentParser(
        description='train',
        formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    parser.add_argument('--lr', type=float, default=0.001,help='learning rate, default:1e-3')
    parser.add_argument('--n_z', type=int, default=16, 
                        help='the number of dimension of latent vectors for each cell, default:16')
    parser.add_argument('--training_epoch', type=int, default=200,
                        help='epoch of train stage, default:200')
    parser.add_argument('--clustering_epoch', type=int, default=100,
                        help='epoch of clustering stage, default:100')
    parser.add_argument('--name', type=str, default='Muraro',
                        help='name of input file(a h5ad file: Contains the raw count matrix "X",)')
    parser.add_argument('--max_num_cell', type=int, default=4000,
                        help='''a maximum threshold about the number of cells use in the model building, 
                        4,000 is the maximum cells that a GPU owning 11 GB memory can handle. 
                        More cells will bemploy the down-sampling straegy, 
                        which has been shown to be equally effective,
                        but it's recommended to process data with less than 24,000 cells at a time''')
    parser.add_argument('--cuda', type=bool, default=True,
                        help='use GPU, or else use cpu (setting as "False")')
    args = parser.parse_args()
    args.cuda = torch.cuda.is_available()
    device = torch.device("cuda" if args.cuda else "cpu")
    simplefilter(action='ignore', category=FutureWarning)
    
    for i in ['Muraro', 'Quake_10x_Bladder', 'Quake_10x_Limb_Muscle', 
              'Quake_10x_Spleen', 
              'Quake_Smart-seq2_Diaphragm', 'Quake_Smart-seq2_Limb_Muscle', 'Quake_Smart-seq2_Lung', 'Quake_Smart-seq2_Trachea',
              'Romanov', 'Pancreas_human1', 'Pancreas_human2', 'Pancreas_human3', 'Pancreas_human4', 'Pancreas_mouse']:
        args.name = i
        ASW = []
        ARI = []
        NMI = []
        adata, rawData, dataset, celltype, adj, r_adj = utils.load_data('./Data/AnnData/{}'.format(args.name),args=args)
        for j in range(5):
            if adata.shape[0] < args.max_num_cell:
                random.seed(1000*j)
                size_factor = adata.obs['size_factors'].values
                Zscore_data = preprocessing.scale(dataset)
                
                args.n_input = dataset.shape[1]
                print(args)
                init_model = AttentionAE(256, 64, 64, 256, n_input=args.n_input, n_z=args.n_z, device=device)
                pretrain_model = train(init_model, Zscore_data, rawData, celltype, adj, r_adj, size_factor, device, args)
            
                asw, ari, nmi, pred_label, _, _ = clustering(pretrain_model, Zscore_data, rawData, celltype, adj, r_adj, size_factor, device, args)
                ASW.append(asw)
                ARI.append(ari)
                NMI.append(nmi)            
                print("Final ASW %.3f, ARI %.3f, NMI %.3f"% (asw, ari, nmi))
                #np.savetxt('./results/%s_predicted_label.csv'%(args.name),pred_label)
            
            #down-sampling input
            else:
                new_adata = utils.down_sampling(adata, args.max_num_cell)
                new_adj, new_r_adj = utils.adata_knn(new_adata, method = 'gauss', n_neighbors = args.n_neighbors, metric='cosine')
                new_Zscore_data = preprocessing.scale(new_adata.X)
                
                size_factor = new_adata.obs['size_factors'].values
                Zscore_data = preprocessing.scale(dataset)
                data = torch.Tensor(Zscore_data).to(device)
                adj = torch.Tensor(adj).to(device)
                new_rawData = new_adata.raw[:, adata.raw.var['highly_variable']].X
                new_celltype = new_adata.obs['celltype']
                args.n_input = dataset.shape[1]
                print(args)
                init_model = AttentionAE(256, 64, 64, 256, n_input=args.n_input, n_z=args.n_z, device=device)
                pretrain_model = train(init_model, new_Zscore_data, new_rawData, new_celltype, 
                                       new_adj, new_r_adj, size_factor, device, args)
                _, _, _, _, cluster_layer, model = clustering(pretrain_model, new_Zscore_data, new_rawData, 
                                                              new_celltype, new_adj, new_r_adj, size_factor, device, args)
            
                with torch.no_grad():
                    z, _, _, _, _  = model(data,adj)
                    _, p = loss_func(z, cluster_layer)
                    pred_label = utils.dist_2_label(p)
                    asw = np.round(silhouette_score(z.detach().cpu().numpy(), pred_label), 3)
                    nmi = np.round(normalized_mutual_info_score(celltype, pred_label), 3)
                    ari = np.round(adjusted_rand_score(celltype, pred_label), 3)
                    ASW.append(asw)
                    ARI.append(ari)
                    NMI.append(nmi)        
                    print("Final ASW %.3f, ARI %.3f, NMI %.3f"% (asw, ari, nmi))
        if i == 'Muraro':
            df_ari = pd.DataFrame(ARI,index=range(5), columns=[args.name,])
            df_asw = pd.DataFrame(ASW,index=range(5), columns=[args.name,])
            df_nmi = pd.DataFrame(NMI,index=range(5), columns=[args.name,])
            
        else:
            df_ari['%s'%(args.name)] = ARI
            df_asw['%s'%(args.name)] = ASW
            df_nmi['%s'%(args.name)] = NMI
        
        df_ari.to_csv('./results/Leiden_ARI.csv')
        df_asw.to_csv('./results/Leiden_ASW.csv')
        df_nmi.to_csv('./results/Leiden_NMI.csv') 
            #np.savetxt('./results/%s_predicted_label.csv'%(args.name),pred_label)
